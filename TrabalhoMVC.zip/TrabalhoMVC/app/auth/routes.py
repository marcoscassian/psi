from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from database import Session
from app.models.user import User

auth_bp = Blueprint("auth", __name__, template_folder="../templates")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        senha = request.form.get("senha")
        session = Session()
        user = session.query(User).filter_by(email=email).first()
        session.close()
        if user and check_password_hash(user.senha, senha):
            login_user(user)
            return redirect(url_for("index"))
        return "Usuário ou senha incorretos!"
    return render_template("login.html")

@auth_bp.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        nome = request.form.get("nome")
        email = request.form.get("email")
        senha = request.form.get("senha")
        hashed_senha = generate_password_hash(senha)
        session = Session()
        novo_user = User(nome=nome, email=email, senha=hashed_senha)
        session.add(novo_user)
        session.commit()
        session.close()
        return redirect(url_for("auth.login"))
    return render_template("cadastro.html")

@auth_bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("index"))
