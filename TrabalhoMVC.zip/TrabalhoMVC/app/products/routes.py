from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_required, current_user
from database import Session
from app.models.product import Product

products_bp = Blueprint("products", __name__, template_folder="../templates")

@products_bp.route("/produtos")
@login_required
def listar_produtos():
    session = Session()
    produtos = session.query(Product).filter_by(id_usuario=current_user.id).all()
    session.close()
    return render_template("produtos.html", produtos=produtos)

@products_bp.route("/produtos/novo", methods=["GET", "POST"])
@login_required
def novo_produto():
    if request.method == "POST":
        nome = request.form.get("nome")
        descricao = request.form.get("descricao")
        preco = float(request.form.get("preco"))

        session = Session()
        produto = Product(nome=nome, descricao=descricao, preco=preco, id_usuario=current_user.id)
        session.add(produto)
        session.commit()
        session.close()

        return redirect(url_for("products.listar_produtos"))

    return render_template("novo_produto.html")

@products_bp.route("/produtos/editar/<int:id>", methods=["GET", "POST"])
@login_required
def editar_produto(id):
    session = Session()
    produto = session.query(Product).filter_by(id=id, id_usuario=current_user.id).first()

    if not produto:
        session.close()
        return "Produto não encontrado ou você não tem permissão!"

    if request.method == "POST":
        produto.nome = request.form.get("nome")
        produto.descricao = request.form.get("descricao")
        produto.preco = float(request.form.get("preco"))

        session.commit()
        session.close()
        return redirect(url_for("products.listar_produtos"))

    session.close()
    return render_template("editar_produto.html", produto=produto)

@products_bp.route("/produtos/excluir/<int:id>")
@login_required
def excluir_produto(id):
    session = Session()
    produto = session.query(Product).filter_by(id=id, id_usuario=current_user.id).first()

    if not produto:
        session.close()
        return "Produto não encontrado ou você não tem permissão!"

    session.delete(produto)
    session.commit()
    session.close()
    return redirect(url_for("products.listar_produtos"))
