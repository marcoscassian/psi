from flask import Flask
from database import engine, Base
from models import *

app = Flask(__name__)

def registrar_rotas(app):
    from auth.routes import auth_bp
    from products.routes import products_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(products_bp)

registrar_rotas(app)

if __name__ == "__main__":
    app.run(debug=True)
