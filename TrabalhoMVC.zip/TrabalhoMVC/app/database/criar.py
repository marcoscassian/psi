from database import engine, Base
from models.user import User
from models.product import Product

print("🛠️ Criando tabelas no banco de dados...")
Base.metadata.create_all(bind=engine)
print("✅ Banco de dados criado: projeto_mvc.db")
