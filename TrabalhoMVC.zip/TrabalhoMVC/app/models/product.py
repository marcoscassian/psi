from sqlalchemy import String, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from database import Base

class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    nome: Mapped[str] = mapped_column(String(50), nullable=False)
    descricao: Mapped[str] = mapped_column(String(100))
    preco: Mapped[float] = mapped_column(Float, nullable=False)
    id_usuario: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=True)
